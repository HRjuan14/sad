mkdir -p /pki/ca && cd /pki/ca
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:4096 -out ca.key
openssl req -x509 -new -key ca.key -sha256 -days 3650   -subj "/C=ES/O=SecureCorp/CN=Juan Root CA - Juan Herrador"   -addext "basicConstraints=critical,CA:TRUE"   -addext "keyUsage=critical,keyCertSign,cRLSign"   -out ca.crt
openssl x509 -in /pki/ca/ca.crt -noout -issuer -dates
clear
mkdir -p /pki/servidor && cd /pki/servidor
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out ldap.key
cat > ldap.ext <<'EOF'
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:ldap.securecorp.local
EOF

openssl req -new -key ldap.key -subj "/C=ES/O=SecureCorp/CN=Juan" -out ldap.csr
openssl x509 -req -in ldap.csr -CA /pki/ca/ca.crt -CAkey /pki/ca/ca.key   -CAcreateserial -days 825 -sha256 -extfile ldap.ext -out ldap.crt
openssl verify -CAfile /pki/ca/ca.crt ldap.crt
openssl x509 -in ldap.crt -noout -subject -issuer
clear
./lab.sh cliente
cler
clear
exit
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ls -l /etc/ldap/tls
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/default/slapd
cat /etc/default/slapd
clear
nano /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/default/slapd
./lab.sh reiniciar
exit
kdb5_util create -s -r SECURECORP.LOCAL
kdb5_util create -s -r SECURECORP.LOCAL
service krb5-kdc start

kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
kadmin.local -q "addprinc jherrador"
kadmin.local -q "addprinc -randkey host/web.securecorp.local" 
kadmin.local -q "addprinc mtorres"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
exit
ldapmodify -Y EXTERNAL -H ldapi:/// <<EOF
dn: cn=rrhh,ou=groups,dc=securecorp,dc=local
changetype: modify
add: memberUid
memberUid: lromero
memberUid: mtorres
EOF

ldapmodify -x -D "cn=admin,dc=securecorp,dc=local" -W <<EOF
dn: cn=rrhh,ou=groups,dc=securecorp,dc=local
changetype: modify
add: memberUid
memberUid: lromero
memberUid: mtorres
EOF

exit
exit
kadmin.local -q "modprinc +disallow_all_tix mtorres"
kinit mtorres
exit
ls
exit
ls
cd /pki/
ls
cd /
clear
cd ..
exit
cd ldif/
cd pki/
clear
cd /pki/
cd /
cd ldif/
ls
nano 02-tu-turno.ldif 
nano 03-tls.ldif 
exit
ls
cd ldif
exit
ls
exit
