clear
exit
cd /ldif/
cat 02-tu-turno.ldif
cat 01-ejemplo.ldif
clear
cat ldif/01-ejemplo.ldif~
clear
cat 02-tu-turno.ldif
cat 01-ejemplo.ldif
clear
nano 02-tu-turno.ldif
cat 02-tu-turno.ldif
clear
nano 02-tu-turno.ldif
cat 02-tu-turno.ldif
clear
ldapadd -x -D "cn=admin,dc=securecorp,dc=local" -w secret -f 02-tu-turno.ldif
clear
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -w secret -f 02-tu-turno.ldif
clear
slapcat -b "cn=config" | grep olcRootPW
clear
cat 02-tu-turno.ldif
clear
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
ldapadd -c -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -w 'SecureCorp2026' -f 02-tu-turno.ldif
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=jherrador,ou=people,dc=securecorp,dc=local" -w 'Juan2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=mtorres,ou=people,dc=securecorp,dc=local" -w 'Marta2026'
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -w 'SecureCorp2026' -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -w 'SecureCorp2026' -s 'Juan2026' "uid=jherrador,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -w 'SecureCorp2026' -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
clear
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=jherrador,ou=people,dc=securecorp,dc=local" -w 'Juan2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=mtorres,ou=people,dc=securecorp,dc=local" -w 'Marta2026'
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn mail
exit
echo "TLS_CACERT /pki/ca/ca.crt" >> /etc/ldap/ldap.conf
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
kinit jherrador
kvno host/web.securecorp.local
kvno host/web.securecorp.local
klist
kdestroy
clear
kinit lromero
kvno host/web.securecorp.local
klist
kdestroy
exit
ls
cd /etc/ldap/ldap.conf 
cd /etc/ldap/
ls
cat ldap.conf 
cd ..
cd ..
clear
ls
exit
cd ldif
cleaar
clear
exit
cd /ldif/
ls
02
cat 02-tu-turno.ldif 
exit
clear
exit
ls
cd /ldif/
ls
cat 02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif -c
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif -c
clear
cd ..
clea
clear
cd /ldif/
ls
cat 01-ejemplo.ldif 
clear
cat 02-tu-turno.ldif 
exit
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif -c
clear
exit
