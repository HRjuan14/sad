kinit jherrador
exit
kinit jherrador
exit
